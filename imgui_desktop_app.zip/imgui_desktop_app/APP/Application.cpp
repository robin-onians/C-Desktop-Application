#include "Application.h"
#include "imgui.h"


//Menu Bar
void APP::RenderMenuBar()
{
    if (ImGui::BeginMainMenuBar())
    {
        if (ImGui::BeginMenu("File"))
        {
            ImGui::MenuItem("(menu)", NULL, false, false);
            if (ImGui::MenuItem("Save and Exit", "Alt+F4")) {
                window_closed = true;
            };
            ImGui::EndMenu();
        }
        ImGui::EndMainMenuBar();
    }
}

void APP::RenderUI()
{

    ImGui::SetNextWindowPos(ImVec2(ImGui::GetMainViewport()->Pos.x, ImGui::GetMainViewport()->Pos.y + 30));

    if (img.my_image_texture != 0) {
        ImGui::Begin("Display", nullptr, 1 | 2);
        ImGui::SetWindowSize(ImVec2(ImGui::GetMainViewport()->Size.x * 0.65, ImGui::GetMainViewport()->Size.y - 30));
        //ImGui::Text("Size = %d x %d", img.my_image_width, img.my_image_height);
        float x = (ImGui::GetWindowSize().x - img.w) * 0.5f;
        float y = (ImGui::GetWindowSize().y - img.h) * 0.5f;
        ImGui::SetCursorPos((ImVec2(x, y)));
        ImGui::Image((void*)(intptr_t)img.my_image_texture, ImVec2(img.my_image_width, img.my_image_height));
        ImGui::End();
    }

    ImGui::SetNextWindowPos(ImVec2(ImGui::GetMainViewport()->Pos.x + ImGui::GetMainViewport()->Size.x * 0.65, ImGui::GetMainViewport()->Pos.y + 30));

    ImGui::Begin("Controls Panel", nullptr, 32 | 1 | 2);
    ImGui::SetWindowSize(ImVec2(ImGui::GetMainViewport()->Size.x * 0.35, ImGui::GetMainViewport()->Size.y - 30));
    static char filepath[128] = "";
    ImGui::Text("Enter File Path:"); ImGui::SameLine(); ImGui::InputText(" ", filepath, IM_ARRAYSIZE(filepath));
    if (ImGui::Button("Load Image"))
    {
        img.read_fresh_image(filepath);
    }
    ImGui::Separator();
    static int width;
    static int height;
    ImGui::Text("Enter Width : "); ImGui::SameLine(); ImGui::InputInt("W", &width);
    ImGui::Text("Enter Height: "); ImGui::SameLine(); ImGui::InputInt("H", &height);
    if (ImGui::Button("Resize Picture"))
    {
        img.resize_with_input(width, height);
        img.write("Processed_Images/IMG_Resized");
        img.write("Your_Processed_Image");
        img.read("Processed_Images/IMG_Resized");
    }
    ImGui::Separator();
    if (ImGui::Button("Scale Down"))
    {
        img.scale_down();
        img.write("Processed_Images/IMG_ScaledDown");
        img.write("Your_Processed_Image");
        img.read("Processed_Images/IMG_ScaledDown");
    }
    ImGui::Separator();
    if (ImGui::Button("Scale Up"))
    {
        img.scale_up();
        img.write("Processed_Images/IMG_ScaledUp");
        img.write("Your_Processed_Image");
        img.read("Processed_Images/IMG_ScaledUp");
    }
    ImGui::Separator();
    if (ImGui::Button("Gray Scale"))
    {
        img.grayscale_avg();
        img.write("Processed_Images/IMG_GrayScale");
        img.write("Your_Processed_Image");
        img.read("Processed_Images/IMG_GrayScale");
    }
    ImGui::Separator();
    if (ImGui::Button("Gray Scale (Preserve Luminance)"))
    {
        img.grayscale_lum();
        img.write("Processed_Images/IMG_GrayScaleLum");
        img.write("Your_Processed_Image");
        img.read("Processed_Images/IMG_GrayScaleLum");
    }
    ImGui::Separator();
    static float color[3] = { 1.0f,0.0f,0.0f };
    ImGui::ColorEdit3("Color", color); // Edit 3 floats representing a color
    if (ImGui::Button("colour grade"))
    {
        img.colour_mask(color[0], color[1], color[2]);
        img.write("Processed_Images/IMG_ColourMask");
        img.write("Your_Processed_Image");
        img.read("Processed_Images/IMG_ColourMask");
    }
    ImGui::Separator();
    if (ImGui::Button("Gaussian Image Blur"))
    {
        //the sum of the absoloute value of all the kernel elements must equal 1
        double gauss[9] = {
        1 / 16., 2 / 16., 1 / 16.,
        2 / 16., 4 / 16., 2 / 16.,
        1 / 16., 2 / 16., 1 / 16.
        };
        img.convolve(0, 3, 3, gauss, 1, 1); // red channel
        img.convolve(1, 3, 3, gauss, 1, 1); // green channel
        img.convolve(2, 3, 3, gauss, 1, 1); // blue channel
        img.write("Processed_Images/IMG_GaussBlur");
        img.write("Your_Processed_Image");
        img.read("Processed_Images/IMG_GaussBlur");
    }
    ImGui::Separator();
    if (ImGui::Button("Edge Detection"))
    {
        img.edge_detect();
        img.read("Processed_Images/IMG_OneChannelEdgeDetect");
        img.write("Your_Processed_Image");
    }
    ImGui::Separator();
    static char message[256] = "";
    ImGui::Text("Enter Message:"); ImGui::SameLine(); ImGui::InputText("  ", message, IM_ARRAYSIZE(message));
    if (ImGui::Button("Encode Message Into Image"))
    {
        img.encodeMessage(message);
        img.write("Processed_Images/IMG_Encoded");
        img.write("Your_Processed_Image");
    }
    ImGui::Separator();
    ImGui::Text("Decoded Message: ");
    ImGui::SameLine();
    ImGui::TextColored(ImVec4(250, 0, 0, 1), decoded_msg_buffer);
    if (ImGui::Button("Decode Message From Image"))
    {
        size_t len = 0;
        img.decodeMessage(decoded_msg_buffer, &len);
    }
    ImGui::Separator();
    if (ImGui::Button("Reset Image"))
    {
        img.reset_image();
        img.write("Processed_Images/IMG_Reset");
        img.write("Your_Processed_Image");
        img.read("Processed_Images/IMG_Reset");
        for (size_t i = 0; decoded_msg_buffer[i] != 0; i++)
        {
            decoded_msg_buffer[i] = 0;
        }
    }
    ImGui::End();
}