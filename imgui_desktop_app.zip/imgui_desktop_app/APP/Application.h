#pragma once
#include "Image.h"

struct APP {

	void RenderUI();

	void RenderMenuBar();
	bool GetWindownClosed() { return window_closed; };

	bool window_closed = false;

	char decoded_msg_buffer[256] = { 0 };

	Image img{"Example_Images/IMG_Dog.jpg"};
	//Image img{"Example_Images/IMG_Hut.jpg"};
	//Image img{"Example_Images/IMG_Engine.png"};
	//Image img{"Example_Images/IMG_Car.jpg"};
	//Image img{"Example_Images/IMG_House.jpg"};
};