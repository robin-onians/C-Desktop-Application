
#define STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_WRITE_IMPLEMENTATION

#include "../stb_image library/stb_image.h"
#include "../stb_image library/stb_image_write.h"

#include "Image.h"
#include "vector"

#define BYTE_BOUND(value) value < 0 ? 0 : (value > 255 ? 255 : value)
//------------------------------------------------------------------------------
//Image Read/Write

Image::Image(const char* filename, int channel_force) {
	//determine file type and save extension
	type = get_file_type(filename);
	if (type != NA) {
		if (read(filename, channel_force)) {
			printf("Read %s\n", filename);
			size = w * h * channels;
		}
		else {
			printf("Failed to read %s\n", filename);
		}
	}
	else{
		printf("Failed to read %s\n", filename);
		printf("File is not a valid type. Choose PNG or JPG\n");
	}
}

//creates a blank image
Image::Image(int w, int h, int channels) : w(w), h(h), channels(channels) {
	size = w * h * channels;
	data = new uint8_t[size];
}

//copies an existing image into new empty image.
Image::Image(const Image& img) : Image(img.w, img.h, img.channels) {
	memcpy(data, img.data, size);
}

Image::~Image() {
	stbi_image_free(data);
}

bool Image::read(std::string filename, int channel_force) {

	//check for file extension in string
	if ((filename.find(".png") == std::string::npos) && (filename.find(".jpg") == std::string::npos)) {
		//no file extension found, add the recorded one
		filename += file_extension;
	}
	//load image data into our data pointer
	const char* fn = filename.c_str();
	data = stbi_load(fn, &w, &h, &channels, channel_force);
	LoadTextureFromFile(filename);
	if (original_data == NULL) {
		original_data = stbi_load(fn, &w, &h, &channels, channel_force);
		ow = w; oh = h; oc = channels;
	}
	channels = channel_force == 0 ? channels : channel_force;
	size = w * h * channels;
	//load image into a OpenGL texture
	return data != NULL;
}

bool Image::read_fresh_image(const char* filename, int channel_force) {

	//determine file type and save extension
	ImageType it = get_file_type(filename);
	if (it != NA) {
		type = it;
		//load image data into our data pointer
		data = stbi_load(filename, &w, &h, &channels, channel_force);
		if (data == NULL)
		{
			printf("Failed to read %s\n", filename);
			return false;
		}
		else 
		{
			//load image into a OpenGL texture
			LoadTextureFromFile(filename);
			channels = channel_force == 0 ? channels : channel_force;
			original_data = stbi_load(filename, &w, &h, &channels, channel_force);
			ow = w; oh = h; oc = channels;
			size = w * h * channels;
			printf("Read %s\n", filename);
		}
	}
	else {
		printf("Failed to read %s\n", filename);
		printf("File is not a valid type. Choose PNG or JPG\n");
		return false;
	}
}

bool Image::write(std::string filename) {
	
	filename += file_extension;
	const char* fn = filename.c_str();
	int success; //for return check to know if image write was succesfull
	switch (type) {
	case PNG:
		success = stbi_write_png(fn, w, h, channels, data, w * channels);
		break;
	case JPG:
		success = stbi_write_jpg(fn, w, h, channels, data, 100); //100 = quality parameter (0-100) 100 = full quality
		break;
	case NA:
		success = 0;
	}
	if (success != 0) {
		printf("Wrote", filename, w, h, channels, size, "\n");
		return true;
	}
	else {
		printf("Failed to write", filename, w, h, channels, size, "\n");
		return false;
	}
}

bool Image::write(std::string filename, std::string extension, ImageType type) {

	filename += extension;
	const char* fn = filename.c_str();
	int success; //for return check to know if image write was succesfull
	switch (type) {
	case PNG:
		success = stbi_write_png(fn, w, h, channels, data, w * channels);
		break;
	case JPG:
		success = stbi_write_jpg(fn, w, h, channels, data, 100); //100 = quality parameter (0-100) 100 = full quality
		break;
	case NA:
		success = 0;
	}
	if (success != 0) {
		printf("Wrote", filename, w, h, channels, size, "\n");
		return true;
	}
	else {
		printf("Failed to write", filename, w, h, channels, size, "\n");
		return false;
	}
}

//check what the image extension is
ImageType Image::get_file_type(const char* filename) {
	const char* ext = strrchr(filename, '.');
	if (ext != nullptr) {
		if (strcmp(ext, ".png") == 0) {
			file_extension = ".png";
			return PNG;
		}
		else if (strcmp(ext, ".jpg") == 0) {
			file_extension = ".jpg";
			return JPG;
		}
	}
	return NA; //no match
}

//load an image into a OpenGL texture with common settings
bool Image::LoadTextureFromFile(std::string filename)
{
	//check for file extension in string
	if ((filename.find(".png") == std::string::npos) && (filename.find(".jpg") == std::string::npos)) {
		//no file extension found, add the recorded one
		filename += file_extension;
	}
	const char* fn = filename.c_str();

	//load from file
	my_image_width = w;
	my_image_height = h;
	unsigned char* image_data = stbi_load(fn, &my_image_width, &my_image_height, NULL, 4);
	if (image_data == NULL)
		return false;

	//create a OpenGL texture identifier
	glGenTextures(1, &my_image_texture);
	glBindTexture(GL_TEXTURE_2D, my_image_texture);

	//setup filtering parameters for display
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); // This is required on WebGL for non power-of-two textures
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE); // This is required on WebGL for non power-of-two textures

	//upload pixels into texture
	#if defined(GL_UNPACK_ROW_LENGTH) && !defined(__EMSCRIPTEN__)
	glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
	#endif
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, my_image_width, my_image_height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image_data);
	stbi_image_free(image_data);

	return true;
}


//------------------------------------------------------------------------------
//Image manip


Image& Image::grayscale_avg() {
	if (channels < 3) {
		printf("Image has less than 3 channels, it is assumed to already be grayscale.", this);
	}
	else {
		for (int i = 0; i < size; i += channels) {
			//(r+g+b)/3
			int gray = (data[i] + data[i + 1] + data[i + 2]) / 3;
			memset(data + i, gray, 3);
		}
	}
	return *this;
}

Image& Image::grayscale_lum() {
	if(channels < 3) {
		printf("Image has less than 3 channels, it is assumed to already be grayscale.", this);
	}
	else {
		for(int i = 0; i < size; i+=channels) {
			int gray = 0.3*data[i] + 0.59*data[i+1] + 0.11*data[i+2]; //RBG coefficient values for luminance preserving grayscale
			memset(data+i, gray, 3);
		}
	}
	return *this;
}

Image& Image::resize_with_input(uint16_t nw, uint16_t nh) {
	channels = oc;
	size = nw * nh * channels;
	uint8_t* newImage = new uint8_t[size];

	float scaleX = (float)nw / (ow);
	float scaleY = (float)nh / (oh);
	uint16_t sx, sy;

	for (uint16_t y = 0; y < nh; ++y) {
		sy = (uint16_t)(y / scaleY);
		for (uint16_t x = 0; x < nw; ++x) {
			sx = (uint16_t)(x / scaleX);

			memcpy(&newImage[(x + y * nw) * channels], &original_data[(sx + sy * ow) * channels], channels);

		}
	}

	w = nw;
	h = nh;
	resize_scale_number = 1.0;
	resizew = nw;
	resizeh = nh;
	delete[] data;
	data = newImage;
	newImage = nullptr;
	colour_changed = false;
	return *this;
}

Image& Image::scale_down()
{
	uint16_t nw;
	uint16_t nh;
	channels = oc;

	if (resizew != 0 || resizeh != 0)
	{
		//image has been resized
		//calculate nw and nh including resizing and then scale with that
		resize_scale_number -= 0.1;
		nw = resizew * resize_scale_number;
		nh = resizeh * resize_scale_number;
	}
	else {
		//scale down w and h by 10%
		//we scale from the original image data to maintain resolution and quality
		scale_number -= 0.1;
		nw = ow * scale_number;
		nh = oh * scale_number;
	}
	size = nw * nh * channels;
	uint8_t* newImage = new uint8_t[size];
	float scaleX = (float)nw / (ow);
	float scaleY = (float)nh / (oh);

	uint16_t sx, sy;

	for (uint16_t y = 0; y < nh; ++y) {
		sy = (uint16_t)(y / scaleY);
		for (uint16_t x = 0; x < nw; ++x) {
			sx = (uint16_t)(x / scaleX);

			memcpy(&newImage[(x + y * nw) * channels], &original_data[(sx + sy * ow) * channels], channels);

		}
	}

	w = nw;
	h = nh;
	delete[] data;
	data = newImage;
	newImage = nullptr;
	colour_changed = false;
	return *this;
}

Image& Image::scale_up()
{
	uint16_t nw;
	uint16_t nh;
	channels = oc;

	if (resizew != 0 || resizeh != 0)
	{
		//image has been resized
		//calculate nw and nh including resizing and then scale with that
		resize_scale_number += 0.1;
		nw = resizew * resize_scale_number;
		nh = resizeh * resize_scale_number;
	}
	else {
		//scale up w and h by 10%
		//we scale from the original image data to maintain resolution and quality
		scale_number += 0.1;
		nw = ow * scale_number;
		nh = oh * scale_number;
	}
	size = nw * nh * channels;
	uint8_t* newImage = new uint8_t[size];
	float scaleX = (float)nw / (ow);
	float scaleY = (float)nh / (oh);
	uint16_t sx, sy;

	for (uint16_t y = 0; y < nh; ++y) {
		sy = (uint16_t)(y / scaleY);
		for (uint16_t x = 0; x < nw; ++x) {
			sx = (uint16_t)(x / scaleX);

			memcpy(&newImage[(x + y * nw) * channels], &original_data[(sx + sy * ow) * channels], channels);

		}
	}

	w = nw;
	h = nh;
	delete[] data;
	data = newImage;
	newImage = nullptr;
	colour_changed = false;
	return *this;
}

//colour grade image modifying the color channels
Image& Image::colour_mask(float r, float g, float b) {
	if (channels < 3) {
		printf("[ERROR] Color mask requires at least 3 channels, but this image has:", channels);
	}
	else {
		uint8_t* newImage = new uint8_t[size];
		for (int i = 0; i < size; i += channels) {

			if (!colour_changed){
				//save original colour data for when colour changes
				newImage[i] = data[i];
				newImage[i + 1] = data[i + 1];
				newImage[i + 2] = data[i + 2];
			}
			
			if (colour_changed){
				//reset colours so the filter doesn't compound
				data[i] = colour_data[i];
				data[i + 1] = colour_data[i + 1];
				data[i + 2] = colour_data[i + 2];
			}

			//apply colour filter
			data[i] *= r;
			data[i + 1] *= g;
			data[i + 2] *= b;
		}
		if (!colour_changed) {
			colour_data = newImage;
			newImage = nullptr;
		}
		colour_changed = true;
	}
	return *this;
}

// (channel, kernel width, kernel height, kernel array, kernel row co-ordinate, kernel column co-ordinate)
Image& Image::convolve(uint8_t channel, uint32_t ker_w, uint32_t ker_h, double ker[], uint32_t cr, uint32_t cc) {
	std::vector<uint8_t> new_data(w * h);
	//uint8_t new_data[w*h];
	uint64_t center = cr*ker_w + cc; // the center index of the kernel
	for(uint64_t k=channel; k<size; k+=channels) { // loop through all pixels of chosen channel
		double c = 0; //hold sum of kernel values
		int a = ker_h - cr;
		for(long i = -((long)cr); i<a; ++i) { //loop through the kernel multiplying each value of the kernel with the pixel under it amd sum into c
			long row = ((long)k/channels)/w-i;
			if(row < 0 || row > h-1) {
				continue;
			}
			int b = ker_w - cc;
			for(long j = -((long)cc); j<b; ++j) {
				long col = ((long)k/channels)%w-j;
				if(col < 0 || col > w-1) {
					continue;
				}
				//current kernel value we're on is in the image
				//compute product of kernel value and pixel it's over and add to sum
				c += ker[center+i*(long)ker_w+j]*data[(row*w+col)*channels+channel]; 
			}
		}
		new_data[k/channels] = (uint8_t)BYTE_BOUND(round(c)); //add new value to array
	}
	for(uint64_t k=channel; k<size; k+=channels) {
		data[k] = new_data[k/channels]; //copy new data into data array
	}
	return *this;
}

Image& Image::edge_detect() {

	//grayscale
	grayscale_avg();
	int img_size = w * h;

	//create a one channel image
	Image gray_blur(w, h, 1);

	//move grayscaled image into a a new one channel image
	for (uint64_t k = 0; k < img_size; ++k) {
		gray_blur.data[k] = data[channels * k];
	}

	//blur the image to reduce noise
	double gauss[9] = {
		1 / 16., 2 / 16., 1 / 16.,
		2 / 16., 4 / 16., 2 / 16.,
		1 / 16., 2 / 16., 1 / 16.
	};
	gray_blur.convolve(0, 3, 3, gauss, 1, 1);

	std::vector<double> tx(img_size);
	std::vector<double> ty(img_size);
	std::vector<double> gx(img_size);
	std::vector<double> gy(img_size);

	//seperable convolution
	//loop over rows and columns of images
	//start at column 1 and end at w-1 otherwise kernel will find and create edge around the border of image.
	//seperable convolution
	for (uint32_t c = 1; c < gray_blur.w - 1; ++c) {
		for (uint32_t r = 0; r < gray_blur.h; ++r) {
			tx[r * gray_blur.w + c] = gray_blur.data[r * gray_blur.w + c + 1] - gray_blur.data[r * gray_blur.w + c - 1];
			ty[r * gray_blur.w + c] = 47 * gray_blur.data[r * gray_blur.w + c + 1] + 162 * gray_blur.data[r * gray_blur.w + c] + 47 * gray_blur.data[r * gray_blur.w + c - 1];
		}
	}
	for (uint32_t c = 1; c < gray_blur.w - 1; ++c) {
		for (uint32_t r = 1; r < gray_blur.h - 1; ++r) {
			gx[r * gray_blur.w + c] = 47 * tx[(r + 1) * gray_blur.w + c] + 162 * tx[r * gray_blur.w + c] + 47 * tx[(r - 1) * gray_blur.w + c];
			gy[r * gray_blur.w + c] = ty[(r + 1) * gray_blur.w + c] - ty[(r - 1) * gray_blur.w + c];
		}
	}

	//Calculate edge intensity and cull noise
	double threshold = 0.09;
	double* g = new double[img_size];
	double x, y;
	for (uint64_t k = 0; k < img_size; ++k) {
		x = gx[k];
		y = gy[k];
		g[k] = sqrt(x * x + y * y);
	}
	//make images
	//for scaling
	//scale up largest pixel value to max (255)
	//scale down smallest pixel value to min (0) so the edges have large contrast
	double max = -INFINITY;
	double min = INFINITY;
	for (uint64_t k = 0; k < img_size; ++k) {
		max = fmax(max, g[k]);
		min = fmin(min, g[k]);
	}
	double v;
	for (uint64_t k = 0; k < img_size; ++k) {

		//v is the relative edge strength
		if (max == min) {
			v = 0;
		}
		else {
			v = (g[k] - min) / (max - min) > threshold ? (g[k] - min) / (max - min) : 0;
		}
		gray_blur.data[k] = (uint8_t)(255 * v);
	}	
	gray_blur.write("Processed_Images/IMG_OneChannelEdgeDetect", file_extension, type);
	return *this;
}

Image& Image::encodeMessage(const char* message) {
	uint32_t len = strlen(message) * 8;
	if(len + STEG_HEADER_SIZE > size) {
		printf("\e[31m[ERROR] This message is too large (%lu bits / %zu bits)\e[0m\n", len+STEG_HEADER_SIZE, size);
		return *this;
	}


	//sets least significant bit of every byte to the corresponding bit in the message we're encoding	
	for(uint8_t i = 0;i < STEG_HEADER_SIZE;++i) {
		//clear the least significant bit
		data[i] &= 0xFE;
		//find the least significant bit of the i byte		
		//shift len over i bits so we're getting the i'th bit of legnth
		//then we logically '&' that with 1 to clear all the upper bits so we are left with a 1 or 0
		//then invert it so we are putting the most significant bit in first
		data[i] |= (len >> (STEG_HEADER_SIZE - 1 - i)) & 1UL;
	}

	//put message into image
	for(uint32_t i = 0;i < len;++i) {

		data[i+STEG_HEADER_SIZE] &= 0xFE;
		//use i/8 to get the next byte in the message array
		//shift over remainder bits (%8) and clear with & 1
		//but most significant bit first (len-1-i)
		data[i+STEG_HEADER_SIZE] |= (message[i/8] >> ((len-1-i)%8)) & 1;
	}
	message_encoded = true;
	return *this;
}

Image& Image::decodeMessage(char* buffer, size_t* messageLength) {
	//check to see if image has been encoded
	if (message_encoded) {
		message_encoded = false;
		uint32_t len = 0;
		for (uint8_t i = 0; i < STEG_HEADER_SIZE; ++i) {
			len = (len << 1) | (data[i] & 1);
		}
		*messageLength = len / 8;

		for (uint32_t i = 0; i < len; ++i) {
			//shift the bits left and get least signifigant bit
			buffer[i / 8] = (buffer[i / 8] << 1) | (data[i + STEG_HEADER_SIZE] & 1);
		}
	}
	return *this;
}

Image& Image::reset_image() {
	data = original_data;
	w = ow;
	h = oh;
	scale_number = 1.0;
	resize_scale_number = 1.0;
	colour_changed = false;
	message_encoded = false;
	return *this;
}