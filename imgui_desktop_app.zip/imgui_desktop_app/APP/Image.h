
#include <complex>

#include "../stb_image library/schrift.h"

#if defined(IMGUIL_OPENGL_ES2)
#include <SDL_opengles2.h>
#else
#include <SDL_opengl.h>
#endif

//encoded image header size = header value * 8
#define STEG_HEADER_SIZE sizeof(uint32_t) * 8


enum ImageType {
	PNG, JPG, NA
};


struct Image {

	//picture info
	uint8_t* data = NULL;	//picture data
	size_t size = 0;		//size of the data 
	int w;					//current width
	int h;					//current height
	int channels;			//how many colour values per pixel

	//opengl info
	int my_image_width = 0;
	int my_image_height = 0;
	GLuint my_image_texture = 0;

	//file info 
	ImageType type;
	std::string file_extension;

	//keep original image data for resizing
	uint8_t* original_data = NULL;
	float scale_number = 1.0;
	int ow;
	int oh;
	int oc;
	uint16_t resizew = 0, resizeh = 0;
	float resize_scale_number = 1.0;
	
	//retain colour memory
	uint8_t* colour_data = NULL;
	bool colour_changed = false;

	//steganography
	bool message_encoded = false;


	//--Image Creation/Read/Write--

	Image(const char* filename, int channel_force = 0);	//create image from filename
	Image(int w, int h, int channels = 3);				//just a blank image to manipulate if we want
	Image(const Image& img);							//copy images
	~Image();

	ImageType get_file_type(const char* filename);
	bool read(std::string filename, int channel_force = 0);
	bool read_fresh_image(const char* filename, int channel_force = 0);
	bool write(std::string filename);
	bool write(std::string filename, std::string extension, ImageType type);
	bool LoadTextureFromFile(std::string filename);


	//--Manipulation Functions--

	Image& resize_with_input(uint16_t nw, uint16_t nh);
	Image& scale_up();
	Image& scale_down();
	Image& grayscale_avg();
	Image& grayscale_lum();
	Image& colour_mask(float r, float g, float b);
	Image& convolve(uint8_t channel, uint32_t ker_w, uint32_t ker_h, double ker[], uint32_t cr, uint32_t cc);
	Image& edge_detect();
	Image& reset_image();
	Image& encodeMessage(const char* message);
	Image& decodeMessage(char* buffer, size_t* messageLength);

};
